#yarn install
npm install

npm run build-keycloak-theme