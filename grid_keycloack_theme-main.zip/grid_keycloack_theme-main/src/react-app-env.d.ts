/// <reference types="react-scripts" />
declare module "*.md" {
    const src: string;
    export default src;
}
